<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <h1>Payment Succussfull</h1>
    item_number: <?=$item_number?> <br>
    txn_id: <?=$txn_id?> <br>
    payment_amt: <?=$payment_amt?> <br>
    currency_code : <?=$currency_code?> <br>
    status: <?=$status?> <br>

    
</body>
</html>