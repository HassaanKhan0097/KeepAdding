<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

    var $loggedUser;
    public function __construct() {
        parent::__construct();

        $this->load->library('paypal_lib');
        $this->load->model('Users_Model');
        $this->load->model('Transactions_Model');
    }

    public function index(){

        $data = $this->session->userdata('registerSession'); 

        //Set variables for paypal form
        $returnURL = base_url().'paypal/success'; //payment success url
        $failURL = base_url().'paypal/fail'; //payment fail url
        $notifyURL = base_url().'paypal/ipn'; //ipn url
        //get particular product data
        // $product = $this->product->getProducts($id);
        $userID = 1; //current user id
        $logo = base_url().'assets/images/logo.png';
         
        $this->paypal_lib->add_field('return', $returnURL);
        $this->paypal_lib->add_field('fail_return', $failURL);
        $this->paypal_lib->add_field('notify_url', $notifyURL);
        $this->paypal_lib->add_field('item_name', $data['user_package']);
        $this->paypal_lib->add_field('custom', '1');
        $this->paypal_lib->add_field('item_number',  $data['user_role']);
        $this->paypal_lib->add_field('amount',  $data['user_price']);        
        $this->paypal_lib->image($logo);
         
        $this->paypal_lib->paypal_auto_form();
    }

    public function success(){
         //get the transaction data
         $paypalInfo = $this->input->get();
           
         $data['item_number'] = $paypalInfo['item_number']; 
         $data['txn_id'] = $paypalInfo["tx"];
         $data['payment_amt'] = $paypalInfo["amt"];
         $data['currency_code'] = $paypalInfo["cc"];
         $data['status'] = $paypalInfo["st"];
          
         //pass the transaction data to view
         $this->load->view('payment-success', $data);
    }

    public function fail(){
        //if transaction cancelled
        $this->load->view('payment-fail');
    }

    public function ipn(){
        
        $user = $this->session->userdata('registerSession'); 
         //paypal return transaction details array
         $paypalInfo    = $this->input->post();
 
         $data['t_user_id'] = $paypalInfo['custom'];
         $data['t_role']    = $paypalInfo["item_number"];
         $data['t_txn_id']    = $paypalInfo["txn_id"];
         $data['t_payment_gross'] = $paypalInfo["mc_gross"];
         $data['t_currency_code'] = $paypalInfo["mc_currency"];
         $data['t_payer_email'] = $paypalInfo["payer_email"];
         $data['t_payment_status']    = $paypalInfo["payment_status"];
         $data['t_created'] = date('Y-m-d');
  
         $paypalURL = $this->paypal_lib->paypal_url;        
         $result    = $this->paypal_lib->curlPost($paypalURL,$paypalInfo);
          
         //check whether the payment is verified
         if(preg_match("/VERIFIED/i",$result)){
             //insert the transaction data into the database
             $this->Users_Model->signup($user);
             $this->Transactions_Model->storeTransaction($data);
         }
    }

}

?>